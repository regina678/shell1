# Shell I/O Redirection and Filterling
0. script that prints “Hello, World”, followed by a new line to the standard output.
1. script that displays a confused smiley "(Ôo).
2. Display the content of the /etc/passwd file.
3. Display the content of /etc/passwd and /etc/hosts.
4. Display the last 10 lines of /etc/passwd
5. Display the first 10 lines of /etc/passwd
6. script that displays the third line of the file iacta.
7. script that creates a file named exactly \*\\'"Best School"\'\\*$\?\*\*\*\*\*:) containing the text Best School ending by a new line.
8. script that writes into the file ls_cwd_content the result of the command ls -la.
9. script that deletes all the regular files (not the directories) with a .js
10. script that deletes all the regular files (not the directories) with a .js
11. script that counts the number of directories and sub-directories in the cd
12.  script that displays the 10 newest files in the current directory.
13. script that takes a list of words as input and prints only words that appear exactly once
14. Display lines containing the pattern “root” from the file /etc/passwd
15. Display the number of lines that contain the pattern “bin” in the file /etc/passwd
16. Display lines containing the pattern “root” from the file /etc
17. Display all the lines in the file /etc/passwd that do not contain the pattern “bin”.
18. Display all lines of the file /etc/ssh/sshd_config starting with a letter.
19. Replace all characters A and c from input to Z and e respectively.
20. Create a script that removes all letters c and C from input.
21. script that reverse its input.
22. displays all users and their home directories, sorted by users.
23. command that finds all empty files and directories in the current directory and all sub-directories.
