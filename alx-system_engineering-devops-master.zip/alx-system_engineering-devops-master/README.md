Task 0. Where am I?
