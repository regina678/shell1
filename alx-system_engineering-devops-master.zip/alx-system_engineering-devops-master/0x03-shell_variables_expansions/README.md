0.script that creates an alias.
1.script that prints hello user
2.Add /action to the PATH.
3.script that counts the number of directories in the PATH.
4.script that lists environment variables.
5.script that lists all local variables and environment variables, and functions.
6.script that creates a new local variable.
7.script that creates a new global variable.
8.script that prints the result of the addition of 128 with the value stored in the environment variable TRUEKNOWLEDGE, followed by a new line.
9.script that prints the result of POWER divided by DIVIDE, followed by a new line.
10.script that displays the result of BREATH to the power LOVE.
11.script that converts a number from base 2 to base 10.
12.script that prints all possible combinations of two letters, except oo.
13.script that prints a number with two decimal places, followed by a new line.
14.script that converts a number from base 10 to base 16.
15.script that encodes and decodes text using the rot13 encryption. Assume ASCII.
16.script that prints every other line from the input, starting with the first line.
17.adds the two numbers stored in the environment variables WATER and STIR and prints the result.
